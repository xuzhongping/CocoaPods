
#import <Foundation/Foundation.h>

/** Bananas are cool */
@interface BananaPrivate : NSObject
@end
